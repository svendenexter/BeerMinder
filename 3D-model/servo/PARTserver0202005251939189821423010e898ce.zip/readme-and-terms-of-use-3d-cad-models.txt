
EN   Your CAD data on 25.05.2020 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 3361480 HGPL-14-40-A-B 
    
    AIS2020, 3361480 HGPL-14-40-A-B---(0), 150927 ZBH-9.ipt
    AIS2020, 3361480 HGPL-14-40-A-B---(0), 189652 ZBH-5.ipt
    AIS2020, 3361480 HGPL-14-40-A-B---(0), 3361480 HGPL-14-40-A-B---(0).iam
    AIS2020, 3361480 HGPL-14-40-A-B---(0), 3361863 HGPL-14-40-A-B---(GEH).ipt
    AIS2020, 3361480 HGPL-14-40-A-B---(0), 3385160 HGPL-BAC-14-40---(J).ipt
    AIS2020, 3361480 HGPL-14-40-A-B---(0), DIN-71412 A M5x0_8_SW7.ipt
    AIS2020, 3361480 HGPL-14-40-A-B---(0), DIN-913 - M3x3.ipt
    AIS2020, 3361480 HGPL-14-40-A-B---(0), DIN-913 - M5x5.ipt
    
    Please also check terms of use at:
    http://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
